from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.tweet_list, name='tweet_list'),
    path('tweet/create/', views.tweet_create, name='tweet_create'),
    path('tweet/<int:pk>/edit/', views.tweet_edit, name='tweet_edit'),
    path('tweet/<int:pk>/delete/', views.tweet_delete, name='tweet_delete'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.user_logout, name='logout'),
    path('profile/', views.profile, name='profile'),



    # login/logout are handled by django.contrib.auth.urls (we included in project urls)
]
